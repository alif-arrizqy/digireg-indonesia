HOW TO INSTALL THIS PROGRAM:

- install virtual enviroment python
python -m venv env

- activate virtual enviroment
-- windows: env\Scripts\activate
--linux: source env/bin/activate

- install requirements package
pip install -r requirements.txt